#ifndef _image_
#define _image_
#include <iostream>
#include <algorithm>
#include <iterator>
#include <vector>
#include <list>
#include "Piksel.h"
#include "SimpOp.h"
#include "KompOp.h"
#include "Layer.h"
#include "Selection.h"
#include "Formatter.h"
#include <string>
#include <map>

class Image {

	int height, width, opacity;
	std::vector<Layer> image;
	std::vector<KompOp> kompozitne;
    std::map<std::string,Selection> selection;

    Image(){}
	static Image* onlyimage;

public:
	friend int main(int args,char* argv[]);
	friend class Selection;
	friend class MyFormatter;

	static Image* getImage();

	auto begin() { return image.begin(); }
	auto end() { return image.end(); }
	auto rbegin() { return image.rbegin(); }
	auto rend() { return image.rend(); }

	int getHeight()const { return height; }
	int getWidth()const { return width; }
	int getOpacity()const { return opacity; }

	void setHeight(int h) { height = h; }
	void setWidth(int w) { width = w; }
	void setOpacity(int o) { opacity = o; }

	void addSelection(Selection &s,std::string naziv) {
		if(selection.find(naziv)==selection.end())	selection[naziv] = s;
		else std::cout << "Postoji vec naziv" << std::endl;
	}

	void addComposite(KompOp& k) {	kompozitne.push_back(k); }

	void izvrsi(Operation *op, int selekcija) {
		
			for (auto &img : image) 
					for (int i = 0; i < height; i++) {
						for (int j = 0; j < width; j++) {
							if (selekcija == 0) {
								Piksel* p[5] = { &img.l[i][j],(i == (height - 1)) ? nullptr : &img.l[i + 1][j], (i == 0) ? nullptr : &img.l[i - 1][j], (j == (width - 1)) ? nullptr : &img.l[i][j + 1], (j == 0) ? nullptr : &img.l[i][j - 1] };
								op->do_operation(p);
							}
							else {
								for (auto sel : selection) {
									if (sel.second.getSelected()) {
										for (auto rect : sel.second.selekcije) {
											if ((rect->pozy <= i && (rect->pozy + rect->b) >= i) && (rect->pozx <= j && (rect->pozx + rect->a) >= j)) {
												Piksel* p[5] = { &img.l[i][j],(i == (height - 1)) ? nullptr : &img.l[i + 1][j], (i == 0) ? nullptr : &img.l[i - 1][j], (j == (width - 1)) ? nullptr : &img.l[i][j + 1], (j == 0) ? nullptr : &img.l[i][j - 1] };
												op->do_operation(p);
											}
										}
									}
								}
							}
						}
				}
	
			if (op->getOp() == -1) this->addComposite(*dynamic_cast <KompOp*> (op));
	}
	
	void addEmptyLayer() { 
		Layer layer;
		image.push_back(*layer.emptyLayer(height, width));
	}

	void addLayer(Formatter& layer, int p) { 

		if (this->image.size()==0) {
			this->setHeight(layer.getHeight());
			this->setWidth(layer.getWidth());
		}
		layer.pixels.resize(this->getHeight());
		std::for_each(layer.pixels.begin(), layer.pixels.end(), [&](std::vector<Piksel> &v) {
			v.resize(this->getWidth());
		});

		Layer slika(height, width,p);
		slika.l.assign(layer.pixels.begin(), layer.pixels.end());
		this->image.push_back(slika);
	}


	Layer& Relative(Image &img) {

		Layer *layer=new Layer(img.getHeight(), img.getWidth());
		std::vector<std::vector<int>> ostalop; 
		std::vector<std::vector<int>> red;
		std::vector<std::vector<int>> green;
		std::vector<std::vector<int>> blue;

		ostalop.resize(img.getHeight());
		red.resize(img.getHeight()); 
		green.resize(img.getHeight()); 
		blue.resize(img.getHeight());
		layer->l.resize(img.getHeight());

		for (int i = 0; i < img.getHeight(); i++) {
			    red[i].resize(img.getWidth()); 
			  green[i].resize(img.getWidth());  
			   blue[i].resize(img.getWidth());
			ostalop[i].resize(img.getWidth());
		   layer->l[i].resize(img.getWidth());

			for (int j = 0; j < img.width; j++) {
			   red[i][j] = 0;  
			 green[i][j] = 0; 
			  blue[i][j] = 0; 
		   ostalop[i][j] = 100;
			}
		}
		
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				for (auto it = img.begin(); it!=img.end(); it++) {
					  red[i][j] += it->l[i][j].getRed() *ostalop[i][j] * it->getOpacity() / 10000;
					green[i][j] += it->l[i][j].getGreen()*ostalop[i][j] * it->getOpacity() / 10000;
					 blue[i][j] += it->l[i][j].getBlue()*ostalop[i][j] * it->getOpacity() / 10000;
				  ostalop[i][j] -= ostalop[i][j]*it->getOpacity() / 100;
				 layer->l[i][j].setPiksel(red[i][j], green[i][j], blue[i][j], 100);
				}
			}
		}
		return *layer;
	}

	void deleteLayer(Layer& layer) {
		std::remove(image.begin(), image.end(), layer);
	}
};

#endif