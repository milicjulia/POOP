#ifndef _kompop_
#define _kompop_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include <list>
#include "Piksel.h"
#include "Layer.h"
#include "Operation.h"
#include "tinyxml2.h"

using namespace tinyxml2;

class KompOp:public Operation{

	std::vector<Operation*> fje;

public:

	KompOp():Operation(1) {}

	void do_operation(Piksel **p)override {
		for (auto x : fje) 	x->do_operation(p);
		opsegPiksel(**p);
	}

	void dodajKompOp(Operation& op) {
		fje.push_back(&op);
	}
	
	int getOp()const override { return -1;}

	void sacuvaj(std::string ime) {
		FILE* izlaz = std::fopen(ime.c_str(), "wb");
		XMLDocument doc;
		XMLNode* msg;

		msg = doc.NewElement("KompozitnaFunkcija");
		doc.InsertFirstChild(msg);

		for (auto op : fje) {
			XMLElement *elem = doc.NewElement("SimpleOperation");
			elem->SetAttribute("br", op->getOp());
			elem->SetAttribute("parameter", op->konst);
			msg->InsertEndChild(elem);
		}
		doc.SaveFile(izlaz,false);
		std::fclose(izlaz);
	}

	void ucitaj(std::string ime) {
		FILE* ulaz = std::fopen(("C:\\Users\\User\\Desktop\\temp\\"+ime).c_str(), "rb");
		XMLDocument doc;
		XMLNode* msg;

		doc.LoadFile(ulaz);
		msg = doc.FirstChildElement();
		XMLElement* elem;
		elem = msg->FirstChildElement("SimpleOperation");

		while (elem != nullptr) {
			int br, par;
			const XMLAttribute *atribute;
			atribute = elem->FindAttribute("br");
			atribute->QueryIntValue(&br);
			atribute = elem->FindAttribute("parameter");
			atribute->QueryIntValue(&par);

			Operation *op = new SimpleOperation(par,br);
			dodajKompOp(*op);
			elem = elem->NextSiblingElement("SimpleOperation");
		}
		std::fclose(ulaz);
	}

};

#endif