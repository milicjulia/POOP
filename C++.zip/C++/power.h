//#ifndef _power_
//#define _power_
//#include <iostream>
//#include <algorithm>
//#include <math.h>
//#include <iterator>
//#include "Image.h"
//#include "Piksel.h"
//#include "Layer.h"
//#include "Operation.h"
//
//class Power: public Operation {
//
//public:
// using Operation::Operation;
//
//	Power(Piksel p, int i):Operation(piksel,t){
//		piksel.red = (int)pow(piksel.red, t);
//		piksel.green = (int)pow(piksel.green, t);
//		piksel.blue = (int)pow(piksel.blue, t);
//		opsegPiksel(piksel);
//	}
//
//
//}
//
//#endif