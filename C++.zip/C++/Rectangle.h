#ifndef _rectangle_
#define _rectangle_
#include <iostream>
#include <algorithm>
#include <math.h>

class Rectangle {

	int a, b;
	int pozx, pozy;

public:

	friend class Image;
	friend class MyFormatter;

	Rectangle(int a, int b,int pozx, int pozy) {
		this->a = a;
		this->b = b;
		this->pozx = pozx;
		this->pozy = pozy;
	}
	
};

#endif