#ifndef _myformatter_
#define _myformatter_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include <fstream>
#include <regex>
#include "tinyxml2.h"
#include "Layer.h"
#include "Image.h"


using namespace tinyxml2;

class MyFormatter:public Formatter{
	
public:
	MyFormatter* open(std::string s)override{
			FILE* file = fopen(s.c_str(), "rb");
			Image& img = *Image::getImage();
			int height, width;

			XMLDocument doc;
			doc.LoadFile(file);
			
			XMLElement *msg = doc.FirstChildElement("Image"); //SLIKA
			XMLElement* properties = msg->FirstChildElement("Properties");
			const XMLAttribute* atribute;
			atribute= properties->FindAttribute("Height");
			atribute->QueryIntValue(&height);
			atribute = properties->FindAttribute("Width");    
			atribute->QueryIntValue(&width);


			XMLElement* layer = properties->FirstChildElement("Layer"); //SLOJEVI
			while (layer != nullptr) {
				MyFormatter *myf = new MyFormatter();
				int opacity;
				atribute = layer->FindAttribute("Opacity");  
				atribute->QueryIntValue(&opacity);
				atribute = layer->FindAttribute("Path");
				std::string s = atribute->Value();
				std::ifstream ulaz(("C:\\Users\\User\\Desktop\\temp\\"+s).c_str());

				std::vector<std::vector<Piksel>>l;
				for (int i = 0; i < height; i++){
					std::vector<Piksel>li;
					for (int j = 0; j < width; j++){
						int R, G, B, A;
						char zarez;
						ulaz >> R >> zarez >> G >> zarez >> B >> zarez>>A>>zarez;
						li.push_back(Piksel(R, G, B, opacity));
					}
					l.push_back(li);
				}
				myf->setHeight(height);
				myf->setWidth(width);
				myf->pixels = l;

				img.addLayer(*myf,opacity);
				
				ulaz.close();
				layer = layer->NextSiblingElement("Layer");
			}


			XMLElement* komp = msg->FirstChildElement("CompositeFunction"); //KOMPOZITNE FUNKCIJE
			XMLElement* function = komp->FirstChildElement("Ime");
			while (function != nullptr) {
				atribute = function->FindAttribute("Path");
				std::string path = atribute->Value();
				KompOp* compop = new KompOp();
				compop->ucitaj(path.c_str());

				img.addComposite(*compop);
				function = function->NextSiblingElement("Ime");
			}


			XMLElement* selection = msg->FirstChildElement("Selections"); //SELEKCIJE
			XMLElement* sel = selection->FirstChildElement("Selection");

			while (sel != nullptr) {
				bool activity;
				atribute = sel->FindAttribute("Activity");
				atribute->QueryBoolValue(&activity);
				atribute = sel->FindAttribute("Name");
				std::string name = atribute->Value();
				atribute = sel->FindAttribute("Path");
				std::string path = atribute->Value();
				std::ifstream ulaz(("C:\\Users\\User\\Desktop\\temp\\"+path).c_str());
				std::string line;
				std::regex REG("([0-9]*).([0-9]*).([0-9]*).([0-9]*).*");
				std::smatch result;

				Selection *newselection = new Selection();
				if (activity == false) newselection->Unselect();
				while (!ulaz.eof()) {
					getline(ulaz, line);
					if (regex_match(line, result, REG)) {
						int pozx = atoi(result.str(1).c_str());
						int pozy = atoi(result.str(2).c_str());
						int a = atoi(result.str(3).c_str());
						int b = atoi(result.str(4).c_str());
						Rectangle *r = new Rectangle(a,b,pozx,pozy);
						newselection->addSelection(*r);
					}
				}

				img.addSelection(*newselection,name);

				ulaz.close();
				sel = sel->NextSiblingElement("Selection");
			}return nullptr;
		}
	
	

	void close(Layer &img, std::string s,int br)override{
		Image *image = Image::getImage();
	/*	FILE* izlaz = std::fopen(s.c_str(), "wb");
		XMLDocument doc;
		XMLNode* msg;

		msg = doc.NewElement("Image");											//IMAGE
		doc.InsertFirstChild(msg);
		XMLElement *picture;
		picture = doc.NewElement("Properties");
		picture->SetAttribute("Height", image->getHeight());
		picture->SetAttribute("Width", image->getWidth());
		*/

		int brojac=1;
		for (auto layer : *image) {												//LAYER
			std::string lejer="layer";
			std::string ime = lejer+std::to_string(brojac) + ".txt";
		/*	XMLElement *l;
			l = doc.NewElement("Layer");
			//l->SetAttribute("Opacity", layer.getOpacity());
			l ->SetAttribute("Path", ime.c_str());
			picture->InsertEndChild(l);*/

			std::ofstream sloj(("C:\\Users\\User\\Desktop\\temp\\"+ime).c_str(),std::ofstream::trunc);
			for (auto red : layer.l) {
				for (auto kolona : red) {
					sloj << std::to_string(kolona.getRed()) << "," << std::to_string(kolona.getGreen())<< "," << std::to_string(kolona.getBlue())  << ","<<std::to_string(kolona.getAlpha())<<",";
				}
			}
			sloj.close();
			brojac++;
		}

	//	msg->InsertFirstChild(picture);


	/*	brojac = 1;
		XMLElement *kompozitna;									//KOMPOZITNA FUNKCIJA
		kompozitna = doc.NewElement("CompositeFunction");

		for (auto fje : image->kompozitne) {
			std::string fja = "function";
			std::string ime = fja + std::to_string(brojac) + ".xml";
			XMLElement *k;
			k = doc.NewElement("Ime");
			k->SetAttribute("Path", ime.c_str());
			kompozitna->InsertEndChild(k);
			brojac++;
			fje.sacuvaj(ime.c_str());
		}
		msg->InsertEndChild(kompozitna);*/


		/*brojac = 1;
		XMLElement *selekcija;									//SELEKCIJE
		selekcija = doc.NewElement("Selections");

		for (auto sel : image->selection) {
			std::string name = "selection";
			std::string ime = name + std::to_string(brojac) + ".txt";
			XMLElement *k;
			k = doc.NewElement("Selection");
			k->SetAttribute("Name", sel.first.c_str());
			k->SetAttribute("Path", ime.c_str());
			k->SetAttribute("Activity", sel.second.getSelected());

			selekcija->InsertEndChild(k);
			std::ofstream ll(ime.c_str());
			for(auto s:sel.second.selekcije){
				ll << s->pozx << " " << s->pozy << " " << s->a << " " << s->b << "\n";
			}
			ll.close();
			brojac++;
		}

		msg->InsertEndChild(selekcija);
		*/

		//doc.SaveFile(izlaz);
		//std::fclose(izlaz);
	}
};

#endif