#ifndef _formatter_
#define _formatter_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include "Layer.h"
#include "Image.h"

class Formatter {
	unsigned int width;
	unsigned int height;
protected:std::vector<std::vector<Piksel>> pixels;
public:
	friend class Image;
	virtual Formatter* open(std::string ime)=0;
	virtual void close(Layer &img,std::string s,int b) = 0;
	unsigned int getHeight()const { return height; }
	unsigned int getWidth()const { return width; }
	void setHeight(unsigned int h) { height = h; }
	void setWidth(unsigned int w) { width = w; }
	std::vector<std::vector<Piksel>> getPiksels() const { return this->pixels; }
	void setPikselsSize(int s) { pixels.resize(s); }
};

#endif