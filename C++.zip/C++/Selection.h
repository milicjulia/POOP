#ifndef _selection_
#define _selection_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include <list>
#include "Rectangle.h"


class Selection {

	std::vector<Rectangle*> selekcije;
	bool selected;

public:
	friend class Image;
	friend class MyFormatter;

	Selection() { selected = true;  }

	void addSelection(Rectangle& r) {	selekcije.push_back(&r);  }
	void Select() { selected = true; }
	void Unselect() { selected = false; }
	bool getSelected()const { return selected; }
	

	//void deleteSelection(Rectangle& r) {
	//	std::remove_if(selekcije.begin(), selekcije.end(), r);
	//}
	//void deleteAllSelection() {
	//	selekcije.clear(); 
	//	//??????????????????????????????????????????????????
	//}
};

#endif