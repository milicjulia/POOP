#ifndef _bmpformatter_
#define _bmpformatter_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <fstream>
#include <cstdlib>
#include <cstddef>
#include <cstdlib>
#include "Formatter.h"
#include "Layer.h"
#include "Piksel.h"

struct bmpfile_magic{
	unsigned char magic[2];
};

struct bmpfile_header{
	uint32_t file_size;
	uint16_t creator1;
	uint16_t creator2;
	uint32_t bmp_offset;
};

struct bmpfile_info{
	uint32_t header_size;
	int32_t width;
	int32_t height;
	uint16_t num_planes{ 1 };
	uint16_t bits_per_pixel;
	uint32_t compression; // 0 za rgb, 3 za rgba
	uint32_t bmp_byte_size;
	int32_t hres;
	int32_t vres;
	uint32_t num_colors{ 0 };
	uint32_t num_important_colors{ 0 };
};

struct bmpfile_color {
	uint32_t red_mask{ 0x00ff0000 };         
	uint32_t green_mask{ 0x0000ff00 };      
	uint32_t blue_mask{ 0x000000ff };     
	uint32_t alpha_mask{ 0xff000000 }; 
	uint32_t color_space_type;
	uint32_t unused[16]{ 0 };   
};


class BMPFormatter:public Formatter{

	bmpfile_header header;
	bmpfile_info info;
	bmpfile_color color;
	bmpfile_magic magic;

	public:
		
		BMPFormatter* open(std::string ime) override{
			BMPFormatter *image=new BMPFormatter();
			std::ifstream ul;

			ul.open(ime, std::ios::in | std::ios::binary);
			if (!ul.is_open()) std::cout << "Greska pri otvaranju slike" << std::endl;
			else
			{
				bmpfile_magic magic;
				ul.read((char*)(&magic), sizeof(magic));

				if (magic.magic[0] != 'B' || magic.magic[1] != 'M')
					std::cout << "Greska pri otvaranju slike" << std::endl;

				else
				{
					ul.read((char*)(&header), sizeof(header));
					ul.read((char*)(&info), sizeof(info));

					image->info.compression = info.compression;
					image->info.height = info.height; 
					image->info.width = info.width;
					image->setHeight(image->info.height);
					image->setWidth(image->info.width);
					image->setPikselsSize(image->getHeight());
					for (int i = 0; i < image->getHeight(); i++)
						image->pixels[i].resize(image->getWidth());

					
					if (info.height <= 0) info.height = -info.height;
					

					if (info.bits_per_pixel != 24 && info.bits_per_pixel != 32)	std::cout << "Greska! Piksel 24b ili 32b mora" << std::endl;


					ul.seekg(header.bmp_offset);

					
					for (int row = 0; row < image->info.height; row++) {
						std::vector <Piksel> red;
						for (int col = 0; col < image->info.width; col++) {
							Piksel piksel;
							int g = ul.get();
							int b = ul.get();
							int r = ul.get();
							if (info.bits_per_pixel == 24) piksel.setPiksel(r, b, g, 100);
							else if (info.bits_per_pixel == 32) {
								int a = ul.get();
								piksel.setPiksel(r, b, g, a);
							}
							image->pixels[row][col].setPiksel(piksel.getRed(), piksel.getBlue(),piksel.getGreen(), piksel.getAlpha());
						}

						int a = (3 * image->info.width) % 4;
						a = (info.bits_per_pixel == 32) ? 0 : (4 - a);
						ul.seekg(a % 4, std::ios::cur);
					}

					ul.close();
				}
			}
			return image;
		}


		void close(Layer &img, std::string s, int b)override {
			std::ofstream izlaz;
			BMPFormatter *bmp = new BMPFormatter();

			izlaz.open(s, std::ios_base::binary);
			if (!izlaz.is_open()) std::cout << "Greska pri otvaranju slike!" << std::endl;
			else
			{
				bmp->magic.magic[0] = 'B'; bmp->magic.magic[1] = 'M';
				izlaz.write((const char*)&bmp->magic, sizeof(bmp->magic));

				bmp->header.bmp_offset = sizeof(magic) + sizeof(header) + sizeof(info);
				bmp->header.file_size = bmp->header.bmp_offset + (img.l.size() * 3 + img.l[0].size() % 4)*img.l.size();
				izlaz.write((const char*)&bmp->header, sizeof(bmp->header));

				bmp->info.header_size = sizeof(info);
				bmp->info.height = img.getHeight();
				bmp->info.width = img.getWidth();
				bmp->info.num_planes = 1;
				bmp->info.bits_per_pixel = b;
				bmp->info.compression = (b == 24) ? 0 : 3;
				bmp->info.bmp_byte_size = 0;
				bmp->info.hres = 2835;
				bmp->info.vres = 2835;
				bmp->info.num_colors = 0;
				bmp->info.num_important_colors = 0;
				izlaz.write((const char*)&bmp->info, sizeof(bmp->info));


				for (int i = 0;i< img.getHeight(); i++) {
					std::vector<Piksel>& red = img.l[i];
					for (int j = 0; j < img.getWidth(); j++) {
						Piksel& p = red[j];
						izlaz.put((unsigned char)(p.getBlue()));
						izlaz.put((unsigned char)(p.getGreen()));
						izlaz.put((unsigned char)(p.getRed()));
						if (b == 32)  izlaz.put((unsigned char)(p.getAlpha()));
					}

					int a = (3 * img.getWidth()) % 4;
					a = (b == 32) ? 0 : (4 - a);
					for (int x = 0; x < a % 4; x++) {
						izlaz.put(0);
					}
				}
				izlaz.close();
			}
		}
		
		
	};

#endif