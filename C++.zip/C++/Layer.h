#ifndef _layer_
#define _layer_
#include <iostream>
#include <algorithm>
#include <vector>
#include "Piksel.h"

class Layer {

protected:
	 int sir, vis;
	 int prozirnost;
public:std::vector<std::vector<Piksel>> l;
	
public:

	friend class Image;
	Layer(){}
	Layer( int v,  int s,int p=100) {
		vis = v;
		sir = s;
		prozirnost = p;
	}

	 int getWidth() const { return sir; }
	 int getHeight() const { return vis; }
	 int getOpacity() const { return prozirnost; }
	 int sizeLayer() const { return vis * sir; }
	void setOpacity(unsigned int o)  {prozirnost=o; }
	void setPixel(unsigned int i,unsigned  int j, const Piksel& piksel){
		l[i][j] = piksel;
	}
	void setHeight(unsigned int h) { vis = h; }
	void setWidth(unsigned int w) { sir = w; }
	std::vector<std::vector<Piksel>> getPiksels() const { return this->l; }
	void shortenLayer() {

	}

	Layer* emptyLayer(int h, int w) {
		Layer layer;
		layer.setHeight(h);
		layer.setWidth(w);
		layer.getPiksels().resize(h);
		for (int i = 0; i < layer.getWidth(); i++) layer.getPiksels()[i].resize(layer.getWidth(), {0,0,0,0});
	}
	friend std::ostream& operator<<(std::ostream& os, const Layer& l) {
	l.printLayer(os);
	return os;
	}

	void printLayer(std::ostream& os)const {
		for (int i = 0; i < this->getHeight(); i++)
			for (int j = 0; j < this->getWidth(); j++)
				os <<"("<< this->l[i][j].getRed() <<","<< this->l[i][j].getGreen()<<"," << this->l[i][j].getBlue() << "," << this->l[i][j].getAlpha()<<")" << std::endl;
		
	}

	bool operator==(const Layer& layer) {
		for (int i = 0; i < layer.getHeight(); i++)
			for (int j = 0; j < layer.getWidth(); j++) {
				if (layer.l[i][j] == this->l[i][j]) continue;
				else return 0;
			}
		return 1;
	}
	friend class Piksel;

	//~Slika() { brisi(); }
};

#endif
