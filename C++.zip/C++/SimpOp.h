#ifndef _simpoperation_
#define _simpoperation_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include "Piksel.h"
#include "Layer.h"
#include "Operation.h"

class SimpleOperation:public Operation {

int operacija;
friend class KompOp;

public:
	
	SimpleOperation(int konst, int op):Operation(konst) { operacija = op; }

	int getOp()const override { return operacija; }
	

	void do_operation(Piksel** p)override {
		switch(operacija) {
		case 1: add(**p); break;
		case 2: sub(**p); break;
		case 3: div(**p); break;
		case 4: mul(**p); break;
		case 5: power(**p); break;
		case 6: lg(**p); break;
		case 7: absolute(**p); break;
		case 8: min(**p); break;
		case 9: max(**p); break;
		case 10: invsub(**p); break;
		case 11: invdiv(**p); break;
		case 12: inverzija(**p); break;
		case 13: gray(**p); break;
		case 14: blackandwhite(**p); break;
		case 15: medijana(p[0],p[1], p[2], p[3], p[4]); break;
		
		}
		
	}

	friend Piksel operator+(Piksel& piksel, const int t);
	friend Piksel operator-(Piksel& piksel, const int t);
	friend Piksel operator/(Piksel& piksel, const int t);
	friend Piksel operator*(Piksel& piksel, const int t);

	
	void add(Piksel& piksel) { piksel = piksel + konst; }
	void sub(Piksel& piksel) { piksel = piksel - konst; }
	void mul(Piksel& piksel) { piksel = piksel * konst; }
	void div(Piksel& piksel) { piksel = piksel / konst; }

	void invsub(Piksel& piksel) { 
		piksel.setRed(konst - piksel.getRed());
		piksel.setGreen(konst - piksel.getGreen());
		piksel.setBlue(konst - piksel.getBlue());
	}

	void invdiv(Piksel& piksel) { 
		piksel.setRed(konst / piksel.getRed());
		piksel.setGreen(konst / piksel.getGreen());
		piksel.setBlue(konst / piksel.getBlue());
		}
	
	void power(Piksel& piksel) {
		piksel.setRed((int)pow(piksel.red, operacija));
		piksel.setGreen((int)pow(piksel.green, operacija));
		piksel.setBlue((int)pow(piksel.blue, operacija));
		opsegPiksel(piksel);
	}

	void lg(Piksel& piksel) {
		piksel.setRed((int)log(piksel.getRed()));
		piksel.setGreen((int)log(piksel.getGreen()));
		piksel.setBlue((int)log(piksel.getBlue()));
	}

	void absolute(Piksel& piksel) {
		piksel.setRed(abs(piksel.getRed()));
		piksel.setGreen(abs(piksel.getGreen()));
		piksel.setBlue(abs(piksel.getBlue()));
	}

	void  min(Piksel& piksel) {
		if (piksel.getRed() > konst) piksel.setRed(konst);
		if (piksel.getGreen() > konst) piksel.setGreen(konst);
		if (piksel.getBlue() > konst) piksel.setBlue(konst);
	}

	void max(Piksel& piksel) {
		if (piksel.getRed() < konst) piksel.setRed(konst);
		if (piksel.getGreen() < konst) piksel.setGreen(konst);
		if (piksel.getBlue() < konst) piksel.setBlue(konst);
	}

	int avg(Piksel& piksel) { return (piksel.getRed() + piksel.getGreen() + piksel.getBlue()) / 3; }

	void inverzija(Piksel& piksel) {
		konst = 255;
		sub(piksel);
		absolute(piksel);
	}

	void blackandwhite(Piksel& piksel) {
		if (isgreaterequal(avg(piksel), 127)) piksel.setPiksel(0, 0, 0, piksel.getAlpha());
		else piksel.setPiksel(255,255,255,piksel.getAlpha());
	}

	void gray(Piksel& piksel) {
		int pom = avg(piksel);
		piksel.setPiksel(pom, pom, pom, piksel.getAlpha());
	}

	void medijana(Piksel *p, Piksel *p1, Piksel *p2, Piksel *p3, Piksel *p4) {
		int pom = 1;
		if (p1 != nullptr)pom++;
		if (p2 != nullptr)pom++;
		if (p3 != nullptr)pom++;
		if (p4 != nullptr)pom++;
		p->setRed((p->getRed()+((p1==nullptr)?0:p1->getRed())+ ((p2 == nullptr) ? 0 : p2->getRed()) + ((p3 == nullptr) ? 0 : p3->getRed()) + ((p4 == nullptr) ? 0 : p4->getRed()))/pom);
		p->setGreen((p->getGreen() + ((p1 == nullptr) ? 0 : p1->getGreen()) + ((p2 == nullptr) ? 0 : p2->getGreen()) + ((p3 == nullptr) ? 0 : p3->getGreen()) + ((p4 == nullptr) ? 0 : p4->getGreen())) / pom);
		p->setBlue((p->getBlue() + ((p1 == nullptr) ? 0 : p1->getBlue()) + ((p2 == nullptr) ? 0 : p2->getBlue()) + ((p3 == nullptr) ? 0 : p3->getBlue()) + ((p4 == nullptr) ? 0 : p4->getBlue())) / pom);

	}

};


#endif

