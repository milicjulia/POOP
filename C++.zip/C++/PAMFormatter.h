#ifndef _pamformatter_
#define _pamformatter_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include <cstddef> 
#include "Formatter.h"

class PAMFormatter :public Formatter {

	std::string tip;
	//unsigned int width;
	//unsigned int height;
	unsigned int depth;
	unsigned int maxval;
	std::string tultype;
	//std::vector<std::vector<Piksel>> pixels;

public:
	PAMFormatter() {}

	Formatter* open(const std::string ime)  override {
		PAMFormatter *image=new PAMFormatter();
		std::ifstream ul;
		std::string rec;

		ul.open(ime,std::ios::binary);
		if (!ul.is_open()) std::cout << "Greska pri otvaranju slike" << std::endl;

		getline(ul, image->tip);
		if (image->tip != "P7") std::cout << "Greska u formatu slike" << std::endl;

		ul >> rec; ul >> rec;  image->setWidth(stoi(rec));
		ul >> rec; ul >> rec; image->setHeight(stoi(rec));
		ul >> rec; ul >> rec;  image->depth = stoi(rec);
		ul >> rec; ul >> rec;  image->maxval = stoi(rec);
		ul >> rec;
		getline(ul, image->tultype);
		ul >> rec;

		image->setPikselsSize(image->getHeight());
		for (int i = 0; i < image->getHeight(); i++)	image->pixels[i].resize(image->getWidth());
//		ul >> rec;
		
		ul.get(); 
			for (int i = image->getHeight() - 1; i>=0; i--) {
				for (int j =0; j<image->getWidth() ; j++) {
					uint8_t r, g, b, a;
					ul.read((char*)&r, 1); ul.read((char*)&g, 1); ul.read((char*)&b, 1); 
					image->pixels[i][j].setRed((int)r);
					image->pixels[i][j].setGreen((int)g);
					image->pixels[i][j].setBlue((int)b);
					if (image->depth == 3) image->pixels[i][j].setAlpha(100); else {
						ul.read((char*)&a, 1);
						image->pixels[i][j].setAlpha((int)a);
					}
				}
			}
		


		/*int pom1 = 0, pom2 = 0;
		for (int i = 0; i < pixels.size(); i++) {
			layer.getPiksels()[pom1][pom2].setPiksel(image.pixels[i].getRed(), image.pixels[i].getGreen(), image.pixels[i].getBlue(), image.pixels[i].getAlpha());
			if (pom2 < layer.getHeight()) pom2++; else {
				pom2 = 0; pom1++;
			}
		}*/

	//	std::cout << "height  "<< layer.getHeight() << "   width "<<layer.getWidth() <<"   tip "<< image.tip <<"   maxval "<< image.maxval << "   tultype "<<image.tultype << std::endl;

		ul.close();
		return image;
	}

	void close(Layer &img, std::string s,int b) override {
		std::ofstream izlaz;
		PAMFormatter pam;
		pam.setHeight(img.getHeight());
		pam.setWidth(img.getWidth());
		pam.maxval = 255; //zavisi od tultype
		pam.tip = "P7";
		pam.tultype = "RGB_ALPHA";//KORISNIK BIRA
		pam.depth = 1;// (1 � greyscale, 3 � RGB, 4 � RGBA)

		izlaz.open(s,std::ios::binary);
		izlaz.write((const char*)"P7\n", 3);
		izlaz.write((const char*)"WIDTH ", 6); izlaz.write((const char*)std::to_string(pam.getWidth()).c_str(), std::to_string(pam.getWidth()).length()) << "\n";
		izlaz.write((const char*)"HEIGHT ", 7); izlaz.write((const char*)std::to_string(pam.getHeight()).c_str(), std::to_string(pam.getHeight()).length()) << "\n";
		izlaz.write((const char*)"DEPTH 4\n", 8);
		izlaz.write((const char*)"MAXVAL 255\n", 11);
		izlaz.write((const char*)"TUPLTYPE RGB_ALPHA\n", 19);
		izlaz.write((const char*)"ENDHDR\n", 7);


		for (int i = img.getHeight() - 1;i>=0; i--) {
			for (int j =0; j<img.getWidth() ; j++) {
				
				int r = img.l[i][j].getRed(); int g= img.l[i][j].getGreen(); int b = img.l[i][j].getBlue(); int a = img.l[i][j].getAlpha();
				
				izlaz.write((const char*)&r,1);
				izlaz.write((const char*)&g, 1);
				izlaz.write((const char*)&b, 1);
				izlaz.write((const char*)&a, 1);
			}
		}
		izlaz.close();

	
	}
};



#endif