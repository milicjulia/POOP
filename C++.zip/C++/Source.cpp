#include <iostream>
#include <fstream>
#include "Image.h"
#include "Piksel.h"
#include "Layer.h"
#include "PAMFormatter.h"
#include "BMPFormatter.h"
#include "SimpOp.h"
#include "KompOp.h"
#include "Selection.h"
#include "Rectangle.h"
#include "MyFormatter.h"

int main(int argc, char *argv[]) {

	if(argc>=2){
		MyFormatter myf;
		BMPFormatter bmp;
	 static KompOp *kompop = new KompOp();
		Image &img = *Image::getImage();
		*myf.open(argv[1]);
		kompop->ucitaj(argv[2]);
		if(img.selection.empty()) img.izvrsi(kompop,0);
		else img.izvrsi(kompop, 1);
		//bmp.close(img.Relative(img), "nekaslika.bmp", 24);
		myf.close(img.Relative(img), argv[1], 24);
		return 0;
	}
	
	Selection *sel = nullptr;
	PAMFormatter pam;
	BMPFormatter bmp;
	MyFormatter myf;
	int k,jednaslika=0;
	std::string name;
	Image &img=*Image::getImage();
	KompOp *kompop = nullptr;
	bool apdejtovano=false;

	std::cout << "MENI" << std::endl;
	std::cout << "1.Uneti novu sliku" << std::endl;
	std::cout << "2.Operacija nad slikom" << std::endl;
	std::cout << "3.Napravi selekciju" << std::endl;
	std::cout << "4.Eksportovati sliku" << std::endl;
	std::cin >> k;

	while (k == 1 || k == 2 || k == 3 || k==4 || k==5) {

		switch (k) {

		case 1: {
			int e, b,p;
			apdejtovano = false;
			std::cout << "U kom formatu importujete? (PAM-0, BMP-1, MY-2) "; std::cin >> e;	std::cout << std::endl;
			std::cout << "Unesite putanju slike (sa odgovarajucom ekstenzijom): "; std::cin >> name;  std::cout << std::endl;
			if (e != 2) { std::cout << "Podesite providnost slike (0-100) ";  std::cin >> p; std::cout << std::endl; }
			if (e == 0)img.addLayer(*pam.open(name), p);
			if (e == 1) img.addLayer(*bmp.open(name), p);
			if (e == 2) *myf.open(name);
			jednaslika++;
			break;
		}
		case 2: {
			if (jednaslika == 0) {
				std::cout << "Greska! Niste uneli nijednu sliku";  std::cout << std::endl; break;
			}
			int p, o, br,s,kompf;
			apdejtovano = false;
			std::cout << "Koliko operacija zelite? ";  
			std::cin >> p;
			std::cout << std::endl; 
			if(p>0) std::cout << "Da li zelite kompozitnu funkciju? (1-da, 0-ne) "; std::cin >> kompf;
			if (kompf == 1) kompop = new KompOp();
		
			std::cout << std::endl;
			std::cout << " 1. Sabiranje" << std::endl;
			std::cout << " 2. Oduzimanje" << std::endl;
			std::cout << " 3. Deljenje" << std::endl;
			std::cout << " 4. Mnozenje" << std::endl;
			std::cout << " 5. Stepenovanje" << std::endl;
			std::cout << " 6. Logaritmovanje" << std::endl;
			std::cout << " 7. Apsolutna vrednost" << std::endl;
			std::cout << " 8. Postavi na minimum" << std::endl;
			std::cout << " 9. Postavi na maksimum" << std::endl;
			std::cout << "10. Inverzno oduzimanje" << std::endl;
			std::cout << "11. Inverzno deljenje" << std::endl;
			std::cout << "12. Inverzija" << std::endl;
			std::cout << "13. Siva slika" << std::endl;
			std::cout << "14. Crno-bela slika" << std::endl;
			std::cout << "15. Medijana" << std::endl;
			std::cout << std::endl;

			while(p>0){

				std::cout << "Unesite redni broj operacije: "; std::cin >> o; std::cout << std::endl;
				
				switch (o) {

				case 1:case 2:case 3:case 4:case 5:case 8:case 9: case 10: case 11:{
					std::cout << "Unesite parametar "; std::cin >> br; 
					if (sel != nullptr) { std::cout << "Da li zelite nad selekcijom? (da-1, ne-0) "; std::cin >> s; }
						else s = 0;
					Operation *op = new SimpleOperation(br,o);
					if (kompf == 1) kompop->dodajKompOp(*op);
						else img.izvrsi(op,s);
					p--;
					std::cout << std::endl; 
				}break;

				case 6: case 7: case 12: case 13: case 14: case 15:{
					br = 0;
					if (sel != nullptr) { std::cout << "Da li zelite nad selekcijom? (da-1, ne-0) "; std::cin >> s; }
					else s = 0;
					Operation *op = new SimpleOperation(br, o);
					if (kompf == 1) kompop->dodajKompOp(*op);
					else img.izvrsi(op, s);
					p--;
					std::cout << std::endl;
				}break;
				}
				}

			if (kompf == 1) img.izvrsi(kompop, s);
		}break;

		case 3: {
			if (jednaslika == 0) {
				std::cout << "Greska! Niste uneli nijednu sliku";  std::cout << std::endl; break;
			}
			apdejtovano = false;
			int brojsel,akt; 
			std::string imesel;
			sel = new Selection();

			std::cout << "Unesite ime selekcije : "; std::cin >> imesel;  std::cout << std::endl;
			std::cout << "Unesite koliko selekcija zelite : "; std::cin >> brojsel;  std::cout << std::endl;
			std::cout << "Da li zelite da bude aktivna selekcija (da-1, ne-0): "; std::cin >> akt;

			while (brojsel-- > 0) {
				int a, b, x, y;
				std::cout << "Unesite dimenzije selekcije (duzina,sirina): ";  std::cout << std::endl;
				std::cout << "Duzina: "; std::cin >> a; std::cout << std::endl;
				std::cout << "Sirina: "; std::cin >> b; std::cout << std::endl;
				std::cout << "Unesite poziciju selekcije: "; std::cout << std::endl;
				std::cout << "X koordinata: "; std::cin >> x; std::cout << std::endl;
				std::cout << "Y koordinata: "; std::cin >> y; std::cout << std::endl;
				Rectangle *r = new Rectangle(a, b, x, y);
				sel->addSelection(*r);
			}
			if (akt == 0)sel->Unselect();
			img.addSelection(*sel,imesel);

		}break;

		case 4: {
			if (jednaslika == 0) {
				std::cout << "Greska! Niste uneli nijednu sliku";  std::cout << std::endl; break;
			}
			int e, b;
			std::cout << "U kom formatu eksportujete? (PAM-0, BMP-1, MY-2) "; std::cin >> e; std::cout<< std::endl;
			if (e != 2) { std::cout << "Da li zelite 24b ili 32b? "; std::cin >> b; std::cout << std::endl; }
			else b = 24;
			std::cout << "Unesite ime nove slike sa odgovarajucom ekstenzijom "; std::cin >> name; std::cout << std::endl;
			if (e == 0) pam.close(img.Relative(img), name, b); 
			if (e == 1) bmp.close(img.Relative(img), name, b);
			if (e == 2) myf.close(img.Relative(img), name, b);
			apdejtovano = true;
		}break;

		case 5: {
			int odluka;
			if (apdejtovano) exit(0);
			else {
				std::cout << "Poslednje izmene nisu sacuvane. Da li ste sigurni da zelite da izadjete? (0-ne, 1-da) ";
				std::cin >> odluka; std::cout << std::endl;
				if (odluka == 1) exit(0);
			}
		}break;

		}

		std::cout << "1.Uneti novu sliku" << std::endl;
		std::cout << "2.Operacija nad slikom" << std::endl;
		std::cout << "3.Napravi selekciju" << std::endl;
		std::cout << "4.Eksportovati sliku" << std::endl;
		std::cout << "5.Izlaz" << std::endl;
		std::cin >> k;
	}
	
	system("pause");
	return 0;
	
}