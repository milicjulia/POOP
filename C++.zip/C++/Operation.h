#ifndef _operation_
#define _operation_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>
#include "Piksel.h"
#include "Layer.h"

 class Operation {

 protected:int konst;

public:
	friend class KompOp;
	Operation(int k) { konst = k; }
	virtual void do_operation(Piksel** p) = 0;
	virtual int getOp()const= 0;
	
};

#endif