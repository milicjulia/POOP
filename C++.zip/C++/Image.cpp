#include "Image.h"
Image* Image::onlyimage = nullptr;
Image* Image::getImage() { if (onlyimage == nullptr) onlyimage = new Image(); return onlyimage; }