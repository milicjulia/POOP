#ifndef _piksel_
#define _piksel_
#include <iostream>
#include <algorithm>
#include <math.h>
#include <iterator>


class Piksel {
public:
	 int red, blue, green, alpha;
	//Piksel(){}
	Piksel( int r = 0,  int g = 0, int b = 0,  int a=0) { red = r; green = g; blue = b; alpha = a; } //ovde uslovi??
	
	 int getRed()  const {/*/ if /*(red >= 0 && red <= 255)*/ return red; }
	 int getGreen()  const{ /*if /*(green >= 0 && green <= 255)*/ return  green; }
	 int getBlue()const  { /*if/* (blue >= 0 && blue <= 255)*/ return  blue; }
	 int getAlpha() const {/* if /*(alpha >= 0 && alpha <= 255)*/ return  alpha; }

	void setRed( int r)  { /*if (r >= 0 && r <= 255)*/ red=r; }
	void setGreen( int g) { /*if (g >= 0 && g <= 255)*/ green = g; }
	void setBlue( int b) {/* if (b >= 0 && b <= 255)*/ blue = b; }
	void setAlpha( int a) { /*if (a >= 0 && a <= 255)*/ alpha = a; }
	void setPiksel( int r,  int g,  int b ,  int a ) {
		setRed(r);
		setGreen(g);
		setBlue(b);
		setAlpha(a);
	}
	
	
	// friend Piksel operator+(Piksel& p,const int& t);
	 //friend Piksel operator-(Piksel p,  int t);
	// friend Piksel operator*(Piksel p,  int t);
	// friend Piksel operator/(Piksel p,  int t);

	 friend Piksel operator+(Piksel& p,const int& t) {
		 Piksel pom = p;
		 pom.setRed(p.getRed()+t);
		 pom.setGreen(p.getGreen() + t);
		 pom.setBlue(p.getBlue() + t);
		 return pom;
	 }

	 friend Piksel operator-(Piksel& p, const int& t) {
		 Piksel pom = p;
		 pom.setRed(p.getRed() - t);
		 pom.setGreen(p.getGreen() - t);
		 pom.setBlue(p.getBlue() - t);
		 return pom;
	 }

	 friend Piksel operator*(Piksel& p, const int& t) {
		 Piksel pom = p;
		 pom.setRed(p.getRed() * t);
		 pom.setGreen(p.getGreen() * t);
		 pom.setBlue(p.getBlue() * t);
		 return pom;
	 }

	 friend Piksel operator/(Piksel& p, const int& t) {
		 Piksel pom = p;
		 pom.setRed(p.getRed() / t);
		 pom.setGreen(p.getGreen() / t);
		 pom.setBlue(p.getBlue() / t);
		 return pom;
	 }

	friend void opsegPiksel(Piksel& p) {
		if (p.red > 255) p.red = 255;
		if (p.red < 0) p.red = 0;
		if (p.blue > 255) p.blue = 255;
		if (p.blue < 0) p.blue = 0;
		if (p.green > 255) p.green = 255;
		if (p.green < 0) p.green = 0;
	}
	
	friend bool operator==(const Piksel& p1, const Piksel& p2) {
		if ((p1.red == p2.red) && (p1.green == p2.green) && (p1.blue == p2.blue)) return true;
		else return false;
	}
};

#endif